#ifndef MODULE_H
#define MODULE_H

void game_loop();
void print_bird(int y, int x, bool f);
void msleep(float ms);
void generate_random_coordinates();
void generate_random_start_position();

#endif
