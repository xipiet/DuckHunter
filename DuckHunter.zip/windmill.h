#ifndef WINDMILL_H
#define WINDMILL_H

void init_windmill();
void update_windmill();
void render_windmill();

#endif